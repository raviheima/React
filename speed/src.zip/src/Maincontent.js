import React from "react";

export default function Maincontent() {
  return (
    <div className="container">
      <h1 className="display-1">Reasons: why I am learning React</h1>
      <ol className="list-group">
        <li className="list-group-item">React Is Cool</li>
        <li className="list-group-item">React is fun to learn</li>
        <li className="list-group-item">React is easy going</li>
      </ol>
    </div>
  );
}