import React from "react"
export default function Footer(){
    return(
        <footer className="footer blockquote-footer">
            <small>
                © 2023 Rav Developments. All Rights Reserved
            </small>
        </footer>
    )
}
